<?php 
require('conf.php');
session_destroy();
header('location:index');